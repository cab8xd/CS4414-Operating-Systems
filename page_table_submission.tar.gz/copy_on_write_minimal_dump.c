#include "pagingtestlib.h"

int main(void) {
    setup();
    enable_dump = 1;
    test_copy_on_write_less_forks(4096, "4096", 1);
    finish();
}