#include "types.h"
#include "stat.h"
#include "user.h"
#include "syscall.h"
// for hw1
int
main(int argc, char *argv[])
{
  printf(1, "writecount is %d \n", writecount());

  setwritecount(1);

  printf(1, "writecount is %d \n", writecount());
  exit();
}
