#include "life.h"
#include <pthread.h>

// struct for thread parameters
struct thread_param{
    pthread_barrier_t* barrier; // the barrier unitialized
    LifeBoard* even_state; 
    LifeBoard* odd_state; 
    int steps;
    int thread_id;
    int threads;
    int begin;
    int end;
    //int work;  
};

/**
 * Helper function for creating & swapping the next state.
 */ 

void *life_thread_function(void* arg){

    // make a pointer equal to args:
    thread_param* t = (thread_param*) arg;

    for (int step = 0; step < t->steps; ++step) {

        /* We use the range [1, width - 1) here instead of
         * [0, width) because we fix the edges to be all 0s.
         */

        // if the step is even, use the odd state to write to the even state.
        if(step % 2 == 1){
                  for (int y = 1; y < t-> odd_state->height() - 1; ++y) {
                    for (int x = 1; x < t-> odd_state->width() - 1; ++x) {

                        int live_in_window = 0;
                        /* For each cell, examine a 3x3 "window" of cells around it,
                        * and count the number of live (true) cells in the window. */
                        for (int y_offset = -1; y_offset <= 1; ++y_offset) {
                            for (int x_offset = -1; x_offset <= 1; ++x_offset) {

                                if (t->odd_state->at(x + x_offset, y + y_offset)) {
                                    ++live_in_window;
                                }
                            }
                        }
                        /* Cells with 3 live neighbors remain or become live.
                        Live cells with 2 live neighbors remain live. */
                        t->even_state->at(x, y) = (
                            live_in_window == 3 /* dead cell with 3 neighbors or live cell with 2 */ ||
                            (live_in_window == 4 && t->odd_state->at(x, y)) /* live cell with 3 neighbors */
                        );
                    }
                }
        }

        // else, the odd iteration uses the even version of the state to write to the odd. 
        else {
             for (int y = 1; y < t->even_state->height() - 1; ++y) {
                for (int x = 1; x < t->even_state->width() - 1; ++x) {

                    int live_in_window = 0;
                    /* For each cell, examine a 3x3 "window" of cells around it,
                    * and count the number of live (true) cells in the window. */
                    for (int y_offset = -1; y_offset <= 1; ++y_offset) {
                        for (int x_offset = -1; x_offset <= 1; ++x_offset) {

                            if (t->even_state->at(x + x_offset, y + y_offset)) {
                                ++live_in_window;
                            }
                        }
                    }
                    /* Cells with 3 live neighbors remain or become live.
                    Live cells with 2 live neighbors remain live. */
                    t->odd_state->at(x, y) = (
                        live_in_window == 3 /* dead cell with 3 neighbors or live cell with 2 */ ||
                        (live_in_window == 4 && t->even_state->at(x, y)) /* live cell with 3 neighbors */
                    );
                }
            }

        }

        // wait for the previous generation to finish before moving forward in steps.
        pthread_barrier_wait(t->barrier);
    }
 

    return NULL;

 }



void simulate_life_parallel(int threads, LifeBoard &state, int steps) {
    pthread_t *id = new pthread_t[threads]; //  list of the thread ids
    thread_param t; 
    pthread_barrier_t barrier;
    pthread_barrier_init(&barrier, NULL, threads); // initializes barrier. 
    LifeBoard odd_state{state.width(), state.height()};
    thread_param *t_list = new thread_param[threads];

    for(int thread = 0; thread < threads; thread++){

        t.begin = thread * (state.height() - 1)/threads + 1;
        t.end = (thread + 1) * (state.height() - 1)/threads + 1;

        if(t.end == state.height()) 
            t.end = state.height() - 1;
        
        t.thread_id = thread; // the id is the thread #.
        t.steps = steps;
        t.even_state = &state;
        t.odd_state = &odd_state;
        t.threads = threads;
        t.barrier = &barrier;
        t_list[thread] = t;
        pthread_create(&id[thread], NULL, life_thread_function, &t_list[thread]);
    }

    for(int thread = 0; thread < threads; thread ++) { 
        pthread_join(id[thread], NULL);
    }

    if(steps & 0x1) swap(state, odd_state);
    pthread_barrier_destroy(&barrier);
    // LB_del(next_state);
    // don't delete any of the states
    delete [] id;
    delete [] t_list;


}
