from concurrent import futures
import logging
import grpc
import twophase_pb2
import twophase_pb2_grpc

# argument notes
# * self - the service object
# * request - argument to the method; a message declared in twophase.proto
# * context - provides access to additional RPC system, such as send back errors

# important classes in twophase_pb2_grpc
# * CoordinatorStub
# * CoordinatorServicer


logger = logging.getLogger(__name__)


class MyWorker(twophase_pb2_grpc.WorkerServicer):

 # store the value and also the state.
    def __init__(self, log):  # S: may change with reordering.
        self._log = log
        self._value = None
        self._id = -1
        self._available = False #alternatively check the status. Change eventually
        if self._log.get_last_entry() != None:  # if there exists a value
            # grab that value from the log
            self._value = self._log.get_last_entry()['value']
            self._available = self._log.get_last_entry()['available']
            self._id = self._log.get_last_entry()['id']

    def SetValue(self, request, context):
        if request.id != self._id:
            context.abort(grpc.StatusCode.INTERNAL, 'context abort')
        #print("setting value")

        self._available = True

        # sets new value
        self._log.set_last_entry({
            'value': request.content,
            'available': self._available,
            'id': self._id
        })
        
        self._value = request.content # added

        #print("returning empty in setvalue")
        return twophase_pb2.Empty()

    def GetCommitted(self, request, context):
        return twophase_pb2.MaybeValue(
            # the availability of the value.? Should return unavailable if coordinator throws exception
            available= self._available,
            content= self._value
        )

    def prepare(self, request, context):
        # M: logged that I prepare in the worker. Told coordinator to agree to commit in message.
        
        if request.id < self._id:
            context.abort(grpc.StatusCode.INTERNAL, 'context abort')

        self._id = request.id
        self._available = False
        self._value = request.content
        self._log.set_last_entry({
            'value': request.content,
            'available': self._available,
            'id': self._id
        })
        return twophase_pb2.Empty()


def create_worker(worker_log, **extra_args):
    server = grpc.server(futures.ThreadPoolExecutor(
        max_workers=1), **extra_args)
    twophase_pb2_grpc.add_WorkerServicer_to_server(
        MyWorker(worker_log), server)
    return server


if __name__ == '__main__':
    import argparse
    import os
    import persistent_log
    import time
    parser = argparse.ArgumentParser(
        description='Run a worker'
    )
    parser.add_argument('server_address')
    parser.add_argument('log_file')
    args = parser.parse_args()
    log = persistent_log.FilePersistentLog(args.log_file)
    server = create_worker(log)
    server.add_insecure_port(args.server_address)
    server.start()
    while True:
        time.sleep(3600)