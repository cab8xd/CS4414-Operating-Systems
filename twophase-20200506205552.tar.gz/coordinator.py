from concurrent import futures
import grpc
import logging
import twophase_pb2
import twophase_pb2_grpc

logger = logging.getLogger(__name__)

# constructor for MyCoordinator
class MyCoordinator(twophase_pb2_grpc.CoordinatorServicer):
    def __init__(self, log, worker_stubs):
        self._log = log 
        self._worker_stubs = worker_stubs
        self._id = -1

        if self._log.get_last_entry() != None: # if there exists a value
            self._id = self._log.get_last_entry()['id']
            self._value = self._log.get_last_entry()['content'] # grab that value from the log
            #self.twophase(self._value)
            state = self._log.get_last_entry()['state']
            m = twophase_pb2.MaybeValue(
                    available = self._log.get_last_entry()['available'],
                    content = self._log.get_last_entry()['content'],
                    id = self._log.get_last_entry()['id']
                )
            if state == 'prepare':
                self.SetValue(m, None)
            elif state == 'commit':
                for worker_stub in self._worker_stubs:
                    worker_stub.SetValue(m)


    def SetValue(self, request, context):
        # wrapper to twophase
        self.twophase(request, context)
        return twophase_pb2.Empty()

    def twophase(self, request, context):
	    # TODO: request votes before setting all the values. 

        self._id = self._id + 1 # coordinator is preparing. Increment by one for unique id.
        # also increments transaction id.
        # print("self id is ", self._id)
        
        # print(" before prepare ")

        # save into log
        self._log.set_last_entry({
            'available' : request.available,
            'content' : request.content,
            'id' : self._id,
            'state' : 'prepare'
        })
        #print(" making new maybe value")
        # make a new maybe message
        m = twophase_pb2.MaybeValue(
            available = request.available,
            content = request.content,
            id = self._id 
        )
        #print("preparing worker stubs")
        # S: another for loop for worker_stub with prepare called on ids based on
        # method in worker.py and declared in proto
        for worker_stub in self._worker_stubs:
            #print("for loop")
            worker_stub.prepare(m)
            #print("Done")
        #print("changing state to commit in last entry")
        # save into the log (committing)
        self._log.set_last_entry({
            'available' : request.available,
            'content' : request.content,
            'id' : self._id, 
            'state' : 'commit'
        })
        #print("worker stub setting value")
        for worker_stub in self._worker_stubs:
            worker_stub.SetValue(m)
        #print('returning empty')


def create_coordinator(coordinator_log, worker_stubs, **extra_args):
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=1, **extra_args))
    twophase_pb2_grpc.add_CoordinatorServicer_to_server(MyCoordinator(coordinator_log, worker_stubs), server)
    return server


if __name__ == '__main__':
    import argparse
    import os
    import persistent_log
    import time
    parser = argparse.ArgumentParser(
        description='Run the coordinator server.'
    )
    parser.add_argument('server_address')
    parser.add_argument('log_file')
    parser.add_argument('worker_addresses', nargs='+')
    args = parser.parse_args()
    log = persistent_log.FilePersistentLog(args.log_file)
    worker_stubs = [
        twophase_pb2_grpc.WorkerStub(grpc.insecure_channel(address)) \
        for address in args.worker_addresses
    ]
    server = create_coordinator(log, worker_stubs)
    server.add_insecure_port(args.server_address)
    server.start()
    while True:
        time.sleep(3600)