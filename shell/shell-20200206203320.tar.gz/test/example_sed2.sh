#!/bin/sh
sed -e 's/baz/YYY/'
